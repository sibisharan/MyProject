<?php require_once("server/connect.php"); ?>
<?php require_once("session.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<?php include_once("bootstrap.php"); ?>
</head>
<body class="main_background">
	<?php include_once("menubar.php"); ?>
</body>
</html>